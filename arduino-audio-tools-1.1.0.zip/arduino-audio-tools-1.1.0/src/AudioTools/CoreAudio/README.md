
This directory contains the most important functionality needed for audio processing.